import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';

export interface Product{
  id: number;
  title:string;
  price:number;
  amount: number;
  image:string;
  description:string;
  stock:number;
  
}
@Injectable({
  providedIn: 'root'
})
export class CartService {
   data: Product[] = [
     {
       id: 0, title: 'Fjallraven - Foldsack No.1 Backpack,Fits 15 Laptops',
       description:'Your perfect pack for everyday use and walks in the forest.',
      price: 8.99,
      stock:100,
       amount:1,
       image:'../../assets/icon/pizza.jpg'
    },
     {
       id: 1, title: 'Mens Casual Premium Slim Fit T-Shirts',
       description:'Slim-fitting style, contrast raglan long sleeve,three-button henley placket.',
      price: 5.49,stock:100, amount:1,
      image:'../../assets/icon/fries.jpg'
    },
     {
       id: 2, title: 'Mens Cotton Jacket',
       description:'Great outerwear jacket for the winter season in Pakistan.',
      price: 4.99,stock:100, amount:1,
      image:'../../assets/icon/OIP.jpg'
    },
     {
       id: 3, title: 'Salad',
       description:'It is good foe health',
      price: 6.99,stock:100, amount:1,
      image:'../../assets/pasrur.jpg'
    }
   ];

   private cart = [];
   private cartItemCount = new BehaviorSubject(0);
  constructor() { }
  getProducts(){
    return this.data;
  }
  getCart(){
    return this.cart;
  }
  getCartItemCount(){
    return this.cartItemCount;
  }

  addProduct(product) {
    let added = false;
    for (let p of this.cart) {
      if (p.id === product.id){
        p.amount += 1;
        added = true;
        break;
      }
    }
    if (!added){
      this.cart.push(product);
    }
    this.cartItemCount.next(this.cartItemCount.value + 1);
  }

  decreaseProduct(product){
    for (let [index, p] of this.cart.entries()){
      if(p.id === product.id){
        p.amount -= 1;
        if(p.amount == 0){
          this.cart.splice(index, 1);
        }
      }
    }
    this.cartItemCount.next(this.cartItemCount.value - 1);
  }

  removeProduct(Product){
    for (let [index, p] of this.cart.entries()){
      if(p.id === Product.id){
        this.cartItemCount.next(this.cartItemCount.value - p.amount);
          this.cart.splice(index, 1);
        
      }
    }
  }
}
